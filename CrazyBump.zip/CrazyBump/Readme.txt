*This will work on both newly installed and pre-installed versions of the software.

Copy "cb_crack.exe" to your Crazy Bump directory which is usually (C:\Program Files (x86)\Crazybump) on 64-bit systems or (C:\Porgram Files\Crazybump) on 32-bit systems.
Run "cb_crack.exe" to start up your program, this will reset your trial every time you run it. (It is recomended to always use this to start crazybump)

Optional: Right click on your shortcut of Crazybump on your desktop and choose properties. In the Target section change the ending only. It is currently "...\CrazyBump.exe"
Change it to "...\cb_crack.exe"